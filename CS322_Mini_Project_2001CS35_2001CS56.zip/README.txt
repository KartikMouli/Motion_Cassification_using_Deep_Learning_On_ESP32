CS322 Mini Project

Motion Classification using Deep Learning on ESP32

Team Members:
Kartik Mouli(2001CS35)
Rohit Ranjan(2001CS56)

Note:
This Folder includes
1)Presentation PPT
2)Source Code
3)Brief Reports (2 Reports as Task divided)

